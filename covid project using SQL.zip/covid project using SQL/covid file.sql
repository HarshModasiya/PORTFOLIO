-- select portfolio_project.covid_vaccination
select * from portfolio_project.coviddeaths
order by 3,4 ;

-- select data that going to be use
select location, date, total_cases, new_cases, total_deaths, population 
from portfolio_project.coviddeaths
order by 2 desc;


-- Total cases vs Total Death
select location,date,total_cases,total_deaths, (total_deaths/total_cases)*100 as Deathpercentage
from portfolio_project.coviddeaths 
where location like '%india%'
order by 1,2;



-- Total cases vs population 
-- how many percentage of population got affected with covid
Select location, date, population, total_cases,  (total_cases/population)*100 As PercentPopulationInfected 
From portfolio_project.coviddeaths
-- Where location Like '%Turkey%'
Order By 5 desc;

-- looking at contries with higher infection rate compared to population
select location,population, max(total_cases) as highestinfectionratecount, Max((total_cases/population))*100 as percentpopulationinfected
from portfolio_project.coviddeaths
group by location, population
order by percentpopulationinfected desc;

-- showing contries with highest death count per population
Select location,  population, max(total_deaths) As HighestDeathCount,  max((total_deaths/population))*100 As PercentPopulationDeath
From portfolio_project.coviddeaths
Where continent is not null
Group By location,population
Order By 3 desc;

-- let's break things down by continent 
select location, max(total_deaths) as totaldeathcount
from portfolio_project.coviddeaths
group by location
order by totaldeathcount desc;

-- contintents with the highest death count per population
select continent, max(total_deaths ) as totaldeathcount
from portfolio_project.coviddeaths
-- where location like '%states%'
where continent is not null 
group by continent  
order by totaldeathcount desc;


-- global numbers 

select date, sum(new_cases),sum(new_deaths), sum(new_deaths)/sum(New_cases)*100 as deathpercentage
from portfolio_project.coviddeaths
-- where location like '%states%'
where continent is not null 
group by date
order by 1,2;

--
Select location,  population, max(total_cases) As HighestInfectionCount,  max((total_cases/population))*100 As PercentPopulationInfected 
From portfolio_project.coviddeaths
Group By location,population
Order By 4 desc;

select * from portfolio_project.coviddeaths as dea
join portfolio_project.covid_vaccination as vac
 on dea.location = vac.location
 and dea.date = vac.date;
 
 

 -- Using CTE to perform Calculation on Partition By in previous query
WITH PopvsVac (Continent, Location, Date, Population, New_Vaccinations, RollingPeopleVaccinated)
AS (
    SELECT dea.continent,dea.location,dea.date,dea.population,vac.new_vaccinations,
        SUM(vac.new_vaccinations) OVER (PARTITION BY dea.Location ORDER BY dea.Date) AS RollingPeopleVaccinated
    FROM portfolio_project.coviddeaths dea
    JOIN portfolio_project.covid_vaccination vac
    ON dea.location = vac.location AND dea.date = vac.date
    WHERE dea.continent IS NOT NULL
)
SELECT *, (RollingPeopleVaccinated / Population) * 100 AS VaccinationPercentage
FROM PopvsVac
ORDER BY Location, Date;


-- Using Temp Table to perform Calculation on Partition By in previous query
-- DROP Table if exists PercentPopulationVaccinated;
CREATE TABLE PercentPopulationVaccinated (
    Continent varchar(255),
    Location varchar(255),
    Date datetime,
    Population numeric,
    New_vaccinations numeric,
    RollingPeopleVaccinated numeric,
    PercentVaccinated numeric
);
INSERT INTO PercentPopulationVaccinated (Continent, Location, Date, Population, New_vaccinations, RollingPeopleVaccinated)
SELECT dea.continent,dea.location,dea.date,dea.population,vac.new_vaccinations,SUM(vac.new_vaccinations) OVER (PARTITION BY dea.Location ORDER BY dea.location, dea.Date) AS RollingPeopleVaccinated
FROM portfolio_project.coviddeaths dea
JOIN
    Portfolio_Project.CovidVaccinations vac ON dea.location = vac.location AND dea.date = vac.date;
UPDATE PercentPopulationVaccinated SET PercentVaccinated = (RollingPeopleVaccinated / Population) * 100;

SELECT *
FROM PercentPopulationVaccinated;



-- Creating View to store data for later visualizations

CREATE VIEW View_PercentPopulationVaccinated AS
SELECT
    dea.continent,
    dea.location,
    dea.date,
    dea.population,
    vac.new_vaccinations,
    SUM(vac.new_vaccinations) OVER (PARTITION BY dea.Location ORDER BY dea.location, dea.Date) AS RollingPeopleVaccinated,
    (SUM(vac.new_vaccinations) OVER (PARTITION BY dea.Location ORDER BY dea.location, dea.Date) / dea.population) * 100 AS PercentVaccinated
FROM
    Portfolio_Project.CovidDeaths dea
JOIN
    portfolio_project.covid_vaccination vac
    ON dea.location = vac.location
    AND dea.date = vac.date;
    
SELECT *
FROM View_PercentPopulationVaccinated;
    


